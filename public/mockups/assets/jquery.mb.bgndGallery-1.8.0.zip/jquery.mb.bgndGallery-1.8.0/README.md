# mb.bgndGallery

__An open source jQuery component to easily build a background gallery.__

![mb.bgndGallery](http://dl.dropbox.com/u/1976976/gitHub//mb.bgndGallery.jpg)

## [go to the demo](http://pupunzi.com/#mb.components/mb.bgndGallery/bgndGallery.html)
## [go to the Doc](http://wiki.github.com/pupunzi/jquery.mb.bgndGallery/)


[jquery.mb.components](http://pupunzi.com/), another way of thinking the web